import Head from 'next/head'
export default function About(){
    return(
        <>
        <Head>
            <title>About Us</title> 
            <meta name="description" content="Codearts Solution Pvt Ltd is a digital marketing agency in Kolkata and Pune. We offer full web marketing solutions in Hyderabad &amp; Banglore. Contact us today."></meta>
        </Head>
            <div class="cs-inner_pages_hero_section pt pb">
                <div class="cs-container">
                    <h1>About Us</h1>
                    <ul class="breadcrumb d-flex align-center justify-center">
                        <li><a href="">Home</a></li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>

            <div class="cs-why_choose_us_section inner pb">
                <div class="cs-container d-flex align-center justify-between">
                    <ul class="cs-why_option">
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/wxnxiano.json" 
                            trigger="loop" 
                            delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">Visit  My Blog</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/fpipqhrr.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">My Podcasts</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/tdxypxgp.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">View My Videos</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/gqzfzudq.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">Social Media</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="cs-about_section pb">
                <div class="cs-container d-flex align-center justify-between">
                    <div class="cs-content_area">
                        <div class="cs-custom_heading">
                            <h4>WHY CHOOSE US</h4>
                            <h2>Change the Way You<br />See Social</h2>
                        </div>
                        <p>We are passionate about our work. Our designers stay ahead of the curve to provide engaging and user-friendly website designs to make your business stand out. Our developers are committed to maintaining the highest web standards so that your site will withstand the test of time. </p>
                        <p>We are passionate about our work. Our designers stay ahead of the curve to provide engaging and user-friendly website designs to make your business stand out. Our developers are committed to maintaining the highest web standards so that your site will withstand the test of time. </p>
                        <div class="cs-list d-flex align-center justify-between">
                            <li>Understand Your Audience</li>
                            <li>Engage Your Community</li>
                            <li>Reach Your Audience</li>
                            <li>Social Media Analytics</li>
                        </div>
                    </div>
                    <div class="cs-right_section">
                        <img src="../images/about_us.jpg" alt="" />
                        <span class="cs-business_label">
                            <h4>Business label</h4>
                            <lord-icon
                                src="https://cdn.lordicon.com/qlbskwpn.json"
                                trigger="loop"
                                delay="2000" 
                                colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                        </span>
                    </div>
                </div>
            </div>

            <div class="cs-about_section cs-seo_company pt pb">
                <div class="cs-container d-flex align-center justify-between">
                    <div class="cs-right_section">
                        <img src="../images/about_us.jpg" alt="" />
                        <span class="cs-business_label">
                            <h4>SEO</h4>
                            <lord-icon
                                src="https://cdn.lordicon.com/uqpazftn.json"
                                trigger="loop"
                                delay="2000" 
                                colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                        </span>
                    </div>
                    <div class="cs-content_area">
                        <div class="cs-custom_heading">
                            <h4>WHY CHOOSE US</h4>
                            <h2>Work With A Dedicated SEO Company</h2>
                        </div>
                        <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has the industry’s standard dummy text ever since the when an.</p>
                        <ul class="seo_list_back">
                            <li class="d-flex align-center">
                                <lord-icon
                                    src="https://cdn.lordicon.com/ajnotayw.json"
                                    trigger="loop"
                                    delay="2000" 
                                    colors="primary:#121331,secondary:#f47514">
                                </lord-icon>
                                <div>
                                    <h3>Appear on the 1st Page of Search Engines</h3>
                                    <p>Why would you work with an SEO services firm that doesn’t provide you with the results</p>
                                </div>
                            </li>
                            <li class="d-flex align-center">
                                <lord-icon
                                    src="https://cdn.lordicon.com/flqcnwch.json"
                                    trigger="loop"
                                    delay="2000" 
                                    colors="primary:#121331,secondary:#f47514">
                                </lord-icon>
                                <div>
                                    <h3>Social Media Marketing (SMO)</h3>
                                    <p>Why would you work with an SEO services firm that doesn’t provide you with the results</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </>
    )
}