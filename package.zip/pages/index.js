import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import Hero from '../components/Home/Hero'
import WhyChooseUs from '../components/Home/WhyChooseUs'
import WhatWeDo from '../components/Services/WhatWeDo'
import Marketing from '../components/Home/Marketing'
import Video from '../components/Home/Video'
import Blogs from '../components/Blogs/Blogs'
export default function Home() {
  return (
    <>
      <Head>
        <title>Codearts Solution Pvt Ltd | Web Marketing | Web Design | App Development</title> 
        <meta name="description" content="Codearts Solution Pvt Ltd is a digital marketing agency in Kolkata and Pune. We offer full web marketing solutions in Hyderabad &amp; Banglore. Contact us today."></meta>
      </Head>
       <Hero />
       <WhyChooseUs />
       <WhatWeDo />
       <Marketing />
       <Video />
       <Blogs />
    </>
  )
}
