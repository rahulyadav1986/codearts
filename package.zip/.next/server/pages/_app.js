(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(282);
;// CONCATENATED MODULE: ./components/Shared/Header.js





function Header() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "cs-ovarlay",
      id: "cs-Ovarlay"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "cs-company_info_right_panel",
      id: "cs-right_panel",
      children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
        href: "",
        className: "cs-brand_logo",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: "../images/logo_mobile.png",
          alt: ""
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: "Codrarts Solution Pvt Ltd is one of the newest and best web design companies in Kolkata, offering a one stop web site design and web development solution for our customers."
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "cs-company_details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          children: "Contact Address"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "cs_contact_details",
          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "d-flex align-center",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                children: "HOUSTON, USA"
              }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "1110 Doral Ln. Houston, TX 77073"]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "d-flex align-center",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                children: "INDIA"
              }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "19 N.S Road Standard chartered Bank 3rd floor, suite no :20 Kolkata 700001"]
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "cs-company_details",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          children: "Contact Info"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "cs_contact_details",
          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "d-flex align-center",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: ["+91-8777691218", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "+91-9104438925"]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "d-flex align-center",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              children: ["projects@codeartssolution.com", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "sukalyanwebdesign@gmail.com"]
            })
          })]
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
      id: "header",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "cs-container d-flex align-center justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "",
          className: "cs-brand_logo",
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "../images/logo.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "cs-header_right d-flex align-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "cs-mobile_hamburger d-flex align-center",
            onclick: "csMenu()",
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {})
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
            className: "cs-menu d-flex align-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "Home"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/about",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "about"
                })
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                  children: ["services ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                    className: "fas fa-chevron-down"
                  })]
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                className: "cs-sub_menu",
                children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "Plugin customization"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "Web Development"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "App Development"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "Web Design"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "App Design"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/",
                    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                      children: "UI/UX Design"
                    })
                  })
                })]
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "latest projects"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "our reviews"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "blog"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: "contact"
                })
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "cs-icon_back d-flex align-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "cs-search d-flex align-center",
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "../images/search.png",
                alt: ""
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "cs-hamburger_menu d-flex align-center",
              children: /*#__PURE__*/jsx_runtime_.jsx("span", {})
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "cs-button",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "",
              className: "d-flex align-center justify-center white",
              children: "Start project"
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "cs-mobile_menu",
        id: "cs-menu",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "header d-flex align-center justify-between",
          children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "",
            className: "cs-brand_logo",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "../images/logo.png",
              alt: ""
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "cross",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "../images/close.png",
              alt: ""
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "cs-menu",
          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "index.html",
              children: "Home"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "about.html",
              children: "about"
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            id: "cs-sub_menu",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              href: "javascript:void(0)",
              children: ["services ", /*#__PURE__*/jsx_runtime_.jsx("span", {})]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
              className: "cs-sub_menu",
              children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "Plugin customization"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "Web Development"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "App Development"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "Web Design"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "App Design"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  href: "service-details.html",
                  children: "UI/UX Design"
                })
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "portfolio.html",
              children: "latest projects"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "reviews.html",
              children: "our reviews"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "blog.html",
              children: "blog"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "contact.html",
              children: "contact"
            })
          })]
        })]
      })]
    })]
  });
}
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
;// CONCATENATED MODULE: external "next/script"
const script_namespaceObject = require("next/script");
var script_default = /*#__PURE__*/__webpack_require__.n(script_namespaceObject);
;// CONCATENATED MODULE: ./components/Layout.js






function Layout({
  children
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Header, {}), /*#__PURE__*/jsx_runtime_.jsx("main", {
      children: children
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://kit.fontawesome.com/a992d6b247.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://cdn.lordicon.com/libs/mssddfmo/lord-icon-2.1.0.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "../js/owl.carousel.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "../js/typed.min.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "../js/jquery.countup.min.js",
      strategy: "beforeInteractive"
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      src: "../js/app.js",
      strategy: "beforeInteractive"
    })]
  });
}
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Layout, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,664], () => (__webpack_exec__(869)));
module.exports = __webpack_exports__;

})();