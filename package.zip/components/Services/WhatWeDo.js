export default function WhatWeDo(){
    return(
        <>
             <div className="cs-services_section pt">
                <div className="cs-container">
                    <div className="cs-custom_heading center">
                        <h4>WHAT WE DO</h4>
                        <h2>What We Offer</h2>
                    </div>  
                    <div className="cs-main_section pt_small">
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s1.png" alt="" />
                                    <img src="../images/s1_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>SEO</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s2.png" alt="" />
                                    <img src="../images/s2_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>Development</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s3.png" alt="" />
                                    <img src="../images/s3_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>Web Design</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s4.png" alt="" />
                                    <img src="../images/s4_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>CMS</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s5.png" alt="" />
                                    <img src="../images/s5_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>Maintenance</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                        <div className="cs-portion">
                            <a href="#" className="cs-heading d-flex">
                                <div className="cs-image_area">
                                    <img src="../images/s6.png" alt="" />
                                    <img src="../images/s6_h.png" className="hover" alt="" />                            
                                </div>
                                <h3>Hosting</h3>
                            </a>
                            <p>Maecenas elementum sapien in metus placerat finibus. Lorem ipsum dolor sit amet, vix an.</p>  
                        </div>
                    </div>  
                </div>
            </div>
        </>
    )
}