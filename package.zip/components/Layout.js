import Header from "./Shared/Header"
import Head from "next/head"
import Script from  'next/script'
export default function Layout({children}) {
    return (
      <>
        
        <Header />
        <main>
            {children}
        </main>

        <Script
            src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"
            strategy="beforeInteractive" 
        />
        <Script
            src="https://kit.fontawesome.com/a992d6b247.js"
            strategy="beforeInteractive" 
        />
        
        <Script
            src="https://cdn.lordicon.com/libs/mssddfmo/lord-icon-2.1.0.js"
            strategy="beforeInteractive" 
        />        
        <Script
            src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js"
            strategy="beforeInteractive" 
        />
        
        <Script
            src="../js/owl.carousel.js"
            strategy="beforeInteractive" 
        />
        <Script
            src="../js/typed.min.js"
            strategy="beforeInteractive" 
        />
        <Script
            src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"
            strategy="beforeInteractive" 
        />
        <Script
            src="../js/jquery.countup.min.js"
            strategy="beforeInteractive" 
        />
        
        <Script
            src="../js/app.js"
            strategy="beforeInteractive" 
        />
   
      </>
    )
  }
  