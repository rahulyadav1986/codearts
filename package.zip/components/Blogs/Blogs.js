export default function Blogs(){
    return(
        <>
            <div className="cs-blogs_section pb">        
                <div className="cs-text_section pt">
                    <div className="cs-container d-flex align-center justify-between">
                        <div className="cs-heading d-flex align-end">
                            <h3>// Trending News</h3>
                            <h2>Our Latest Blogs And<br />Attractive News</h2>
                        </div>
                        <p>Hiring an SEO expert could well prove to be a shot in the arm for your online business, that deserves a robust web presence. Hiring an SEO expert could well prove to be a shot in the arm for your online business, that deserves a robust and web presence.</p>
                    </div>
                </div>
                <div className="cs-main_blog_section">
                    <div className="cs-container">
                        <div className="cs-blog_items owl-carousel" id="blogs-slider">
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b1.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b2.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b3.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b1.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b2.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                            <div className="cs-blog_item">
                                <div className="cs-blog_pic_back">
                                    <img src="../images/b3.jpg" alt="" />
                                    <a href="" className="cs-circle d-flex align-center justify-center">
                                        <lord-icon
                                            src="https://cdn.lordicon.com/zpcieyfp.json"
                                            trigger="loop"
                                            colors="primary:#ffffff,secondary:#000000">
                                        </lord-icon>
                                    </a>
                                </div>
                                <div className="cs-content_area">
                                    <div className="cs-widget_section d-flex align-center">
                                        <div className="cs-date d-flex align-center">
                                            <lord-icon
                                                src="https://cdn.lordicon.com/wrhxfrid.json"
                                                trigger="loop"
                                                colors="primary:#121331,secondary:#f47514">
                                            </lord-icon>
                                            April 10, 2020
                                        </div>
                                        <div className="cs-category">Management</div>
                                    </div>
                                    <h2><a href="">Critical Things to Consider When Optimizing WordPress</a></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}