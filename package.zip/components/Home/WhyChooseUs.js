import Image from 'next/image'
export default function WhyChooseUs() {
    return (
      <>
        <div className="cs-why_choose_us_section">
            <div className="cs-container d-flex align-center justify-between">
                <div className="cs-left_section">
                    <ul className="cs-why_option">
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/wxnxiano.json" 
                            trigger="loop" 
                            delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">Visit  My Blog</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/fpipqhrr.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">My Podcasts</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/tdxypxgp.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">View My Videos</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                        <li>
                            <lord-icon 
                            src="https://cdn.lordicon.com/gqzfzudq.json" 
                            trigger="loop" delay="2000" 
                            colors="primary:#121331,secondary:#f47514">
                            </lord-icon>
                            <h3><a href="">Social Media</a></h3>
                            <p>We use creative ideas for your future success.</p>
                        </li>
                    </ul>
                </div>
                <div className="cs-right_section">
                    <div className="cs-custom_heading">
                        <h4>WHY CHOOSE US</h4>
                        <h2>Change the Way You<br />See Social</h2>
                    </div>                
                    <p>We are passionate about our work. Our designers stay ahead of the curve to provide engaging and user-friendly website designs to make your business stand out. Our developers are committed to maintaining the highest web standards so that your site will withstand the test of time.</p>
                    <div className="cs-list d-flex align-center justify-between">
                        <li>Understand Your Audience</li>
                        <li>Engage Your Community</li>
                        <li>Reach Your Audience</li>
                        <li>Social Media Analytics</li>
                    </div>
                    <div className="cs-button small">
                        <a href="" className="d-flex align-center justify-center">Discover More</a>
                    </div>
                </div>
            </div>
        </div>
      </>
    )
  }