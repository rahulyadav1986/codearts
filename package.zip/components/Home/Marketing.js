export default function Marketing(){
    return(
        <>
            <div className="cs-marketing_section pt pb">
                <div className="cs-container d-flex align-center justify-between">
                    <div className="cs-left_section">
                        <p>Praesent sollicitudin felis a ornare volutpat. Nullam males uada sem sit amet semper tristique. Donec nec neque lectus. Nunc mattis, lect us eu lacinia pretium, nisl nisi interdum tortor, id lacinia massa purus feugiat nunc. Pellentesue ligula pellentesque, gravida nisi ac, facilisis sapien Dotas a metus eu, efficitur sodales.<br /><br />

                        interdum tortor, id lacinia massa purus feugiat nunc. Pellique aliquet ssa purus feugiat nunc. Pellentes ue ligula pellent.</p>
                        <div className="cs-action_button">
                            <li>
                                <a href="" className="d-flex align-center">
                                    <lord-icon
                                        src="https://cdn.lordicon.com/xqfngtiz.json"
                                        trigger="loop"
                                        delay="2000"
                                        colors="primary:#121331,secondary:#f47514" 
                                    >
                                    </lord-icon>
                                
                                    Inspiration Design
                                </a>
                            </li>
                            <li>
                                <a href="" className="d-flex align-center">
                                    <lord-icon
                                        src="https://cdn.lordicon.com/ochimkct.json"
                                        trigger="loop"
                                        delay="2000"
                                        colors="primary:#121331,secondary:#f47514" 
                                    >
                                    </lord-icon>
                                    Development
                                </a>
                            </li>
                            <li>
                                <a href="" className="d-flex align-center">
                                    <lord-icon
                                        src="https://cdn.lordicon.com/flqcnwch.json"
                                        trigger="loop"
                                        delay="2000"
                                        colors="primary:#121331,secondary:#f47514"
                                    >
                                    </lord-icon>
                                    Digital Marketing
                                </a>
                            </li>
                            <li> 
                                <a href="" className="d-flex align-center">
                                    <lord-icon
                                        src="https://cdn.lordicon.com/krwjeutf.json"
                                        trigger="loop"
                                        delay="2000"
                                        colors="primary:#121331,secondary:#f47514"
                                    >
                                    </lord-icon>
                                    Technical
                                </a>
                            </li>
                        </div>
                    </div>
                    <div className="cs-right_section">
                        <img src="../images/marketing_bg.png" alt="" />
                        <div className="cs-content_area">
                            <div className="cs-custom_heading">
                                <img src="../images/blub.png" alt="" />
                                <h2>Have a project in mind? Let’s get to work.</h2>
                                <p>Find out how it works and ask<br />any questions you may have.</p>
                            </div>
                            <div className="cs-button small">
                                <a href="" className="d-flex align-center justify-center">Discover More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}