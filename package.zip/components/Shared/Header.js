import Image from 'next/image'
import Link from 'next/link'
export default function Header() {
    return (
      <>
        

        <div className="cs-ovarlay" id="cs-Ovarlay"></div>

        <div className="cs-company_info_right_panel" id="cs-right_panel">
            <a href="" className="cs-brand_logo"><img src="../images/logo_mobile.png" alt="" /></a>
            <p>Codrarts Solution Pvt Ltd is one of the newest and best web design companies in Kolkata, offering a one stop web site design and web development solution for our customers.</p>
            <div className="cs-company_details">
                <h3>Contact Address</h3>
                <ul className="cs_contact_details">
                    <li className="d-flex align-center">
                        
                        
                        <p>
                            <strong>HOUSTON, USA</strong><br />
                            1110 Doral Ln. Houston, TX 77073
                        </p>
                    </li>
                    <li className="d-flex align-center">
                       
                        <p>
                            <strong>INDIA</strong><br />
                            19 N.S Road Standard chartered Bank 3rd floor, suite no :20 Kolkata 700001
                        </p>
                    </li>
                </ul>
            </div>
            <div className="cs-company_details">
                <h3>Contact Info</h3>
                <ul className="cs_contact_details">
                    <li className="d-flex align-center">
                       
                        <p>+91-8777691218<br />+91-9104438925</p>
                    </li>
                    <li className="d-flex align-center">
                       
                        <p>projects@codeartssolution.com<br />sukalyanwebdesign@gmail.com</p>
                    </li>
                </ul>
            </div>
        </div>

        <header id="header">
            <div className="cs-container d-flex align-center justify-between">
                <a href="" className="cs-brand_logo"><img src="../images/logo.png" alt="" /></a>
                <div className="cs-header_right d-flex align-center">
                    <div className="cs-mobile_hamburger d-flex align-center" onclick="csMenu()">
                        <span></span>
                    </div>
                    <ul className="cs-menu d-flex align-center" >
                        <li><Link href="/"><a>Home</a></Link></li>
                        <li><Link href="/about"><a>about</a></Link></li>
                        <li><Link href="/"><a>services <i className="fas fa-chevron-down"></i></a></Link>
                            <ul className="cs-sub_menu">
                                <li><Link href="/"><a>Plugin customization</a></Link></li>
                                <li><Link href="/"><a>Web Development</a></Link></li>
                                <li><Link href="/"><a>App Development</a></Link></li>
                                <li><Link href="/"><a>Web Design</a></Link></li>
                                <li><Link href="/"><a>App Design</a></Link></li>
                                <li><Link href="/"><a>UI/UX Design</a></Link></li>
                            </ul>
                        </li>
                        <li><Link href="/"><a>latest projects</a></Link></li>
                        <li><Link href="/"><a>our reviews</a></Link></li>
                        <li><Link href="/"><a>blog</a></Link></li>
                        <li><Link href="/"><a>contact</a></Link></li>
                    </ul>
                    <div className="cs-icon_back d-flex align-center">
                        <div className="cs-search d-flex align-center"><img src="../images/search.png" alt="" /></div>
                        <div className="cs-hamburger_menu d-flex align-center">
                            <span></span>
                        </div>
                    </div>                
                    <div className="cs-button">
                        <a href="" className="d-flex align-center justify-center white">Start project</a>
                    </div>
                </div>
            </div>
            
            <div className="cs-mobile_menu" id="cs-menu">
                <div className="header d-flex align-center justify-between">
                    <a href="" className="cs-brand_logo"><img src="../images/logo.png" alt="" /></a>
                    <div className="cross"><img src="../images/close.png" alt="" /></div>
                </div>
                
                <ul className="cs-menu">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">about</a></li>
                    <li id="cs-sub_menu"><a href="javascript:void(0)">services <span></span></a>
                        <ul className="cs-sub_menu">
                            <li><a href="service-details.html">Plugin customization</a></li>
                            <li><a href="service-details.html">Web Development</a></li>
                            <li><a href="service-details.html">App Development</a></li>
                            <li><a href="service-details.html">Web Design</a></li>
                            <li><a href="service-details.html">App Design</a></li>
                            <li><a href="service-details.html">UI/UX Design</a></li>
                        </ul>
                    </li>
                    <li><a href="portfolio.html">latest projects</a></li>
                    <li><a href="reviews.html">our reviews</a></li>
                    <li><a href="blog.html">blog</a></li>
                    <li><a href="contact.html">contact</a></li>
                </ul>
            </div>
        </header>
      </>
    )
  }